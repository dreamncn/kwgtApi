<?php
/*******************************************************************************
 * Copyright (c) 2020. CleanPHP. All Rights Reserved.
 ******************************************************************************/

use app\vendor\event\EventManager;
//注册拓展运行位置
EventManager::attach("afterFrameInit", 'app\extend\net_ankio_tasker\Main');

